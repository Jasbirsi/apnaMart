package persons;

/**
 * @author Fathy & Najm
 */
public class Student extends Person {

    public Student() {
    }

    @Override
    public void addPerson() {
        super.addPerson();
    }

}
