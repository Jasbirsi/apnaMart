package operations;

/**
 * @author Fathy & Najm
 */
public interface Operation {

    public void operation();

}
