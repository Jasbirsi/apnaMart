package com.example.project.bookmyshowbackend.dto.EntryRequest;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UserEntryDto {

    String name;
    String mobNo;
}
