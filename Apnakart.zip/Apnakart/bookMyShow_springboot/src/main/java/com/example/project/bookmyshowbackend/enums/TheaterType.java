package com.example.project.bookmyshowbackend.enums;

public enum TheaterType {

    SINGLE,
    MULTIPLEX
}
