package com.example.project.bookmyshowbackend.Repository;


import com.example.project.bookmyshowbackend.Model.TheaterEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TheaterRepository extends JpaRepository<TheaterEntity,Integer> {

}
