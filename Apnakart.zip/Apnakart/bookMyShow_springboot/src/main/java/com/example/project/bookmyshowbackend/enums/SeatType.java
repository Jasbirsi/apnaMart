package com.example.project.bookmyshowbackend.enums;

public enum SeatType {

    CLASSIC,
    PREMIUM
}
