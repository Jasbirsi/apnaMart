package com.example.project.bookmyshowbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookMyShowBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
