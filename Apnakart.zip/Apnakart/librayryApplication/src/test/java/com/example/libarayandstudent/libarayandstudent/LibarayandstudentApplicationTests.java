package com.example.libarayandstudent.libarayandstudent;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibarayandstudentApplicationTests {

	@Test
	void contextLoads() {
	}

}
