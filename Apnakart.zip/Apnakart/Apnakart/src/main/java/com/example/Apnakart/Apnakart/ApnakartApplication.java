package com.example.Apnakart.Apnakart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApnakartApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApnakartApplication.class, args);
	}

}
