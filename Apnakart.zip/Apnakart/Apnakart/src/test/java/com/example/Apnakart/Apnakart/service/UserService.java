package com.example.Apnakart.Apnakart.service;

import com.example.Apnakart.Apnakart.Converter.UserConverter;
import com.example.Apnakart.Apnakart.DTO.UserEntryDto;
import com.example.Apnakart.Apnakart.models.User;
import com.example.Apnakart.Apnakart.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    UserRepository userRepository;


    public void addUser(UserEntryDto userEntryDto) throws Exception {

        if (userRepository.existsbyEmail(userEntryDto.getMobile()) != null) {
            throw new Exception("mobile no already present");
        }
        User userEntity = UserConverter.convertDtoToEntity(userEntryDto); //Cleaner
        userRepository.save(userEntity);
    }

    public void login(UserEntryDto userEntryDto) throws Exception{

        User user=userRepository.existsbyEmail(userEntryDto.getEmail());
        if ( user == null){
            throw new Exception("Email not present");
        }
        else {
            if (user.getPassword() != userEntryDto.getPassword()){
                throw new Exception("Password is Incorect");
            }
        }
    }

}
