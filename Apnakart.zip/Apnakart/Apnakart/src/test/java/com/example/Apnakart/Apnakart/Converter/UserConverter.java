package com.example.Apnakart.Apnakart.Converter;

import com.example.Apnakart.Apnakart.DTO.UserEntryDto;
import com.example.Apnakart.Apnakart.models.User;

public class UserConverter {


    public static User convertDtoToEntity(UserEntryDto userEntryDto){

        return User.builder().Name(userEntryDto.getName()).Mobile(userEntryDto.getMobile()).Email(userEntryDto.getEmail()).Password(userEntryDto.getPassword()).build();


    }





}

