package com.example.Apnakart.Apnakart.Controller;

import com.example.Apnakart.Apnakart.DTO.UserEntryDto;
import com.example.Apnakart.Apnakart.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;



@RestController
@RequestMapping("user")
public class MainControler {


    @Autowired
    UserService userService;

    @PostMapping("signup")
    public ResponseEntity signup(@RequestBody UserEntryDto userEntryDto) throws Exception{

        try {
            userService.addUser(userEntryDto);
            return new ResponseEntity("User added successfully", HttpStatus.CREATED);
        }
        catch (Exception e)
        {
//            throw new Exception(e);
            return new ResponseEntity<>(""+e,HttpStatus.ALREADY_REPORTED);
        }




    }

    @GetMapping("login")
    public ResponseEntity login(@RequestBody UserEntryDto userEntryDto) throws Exception{

        try {
            userService.login(userEntryDto);
            return new ResponseEntity("Login successfully", HttpStatus.CREATED);
        }
        catch (Exception e)
        {
//            throw new Exception(e);
            return new ResponseEntity<>(""+e,HttpStatus.ALREADY_REPORTED);
        }




    }



}
