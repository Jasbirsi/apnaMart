package com.example.Apnakart.Apnakart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApnakartApplicationTests {

	@Test
	void contextLoads() {
	}

}
