package com.example.Apnakart.Apnakart.models;

import lombok.*;

import javax.persistence.*;
import java.util.List;

@Getter
@Setter
@Entity
@Table(name = "users")
@NoArgsConstructor
@Builder
@AllArgsConstructor
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int Id;

    @Column(name = "User name", nullable = false)
    private String Name;


    @Column(name = "Mobile", nullable = false,unique = true)
    private String Mobile;

    @Column(name = "Email", nullable = false,unique = true)
    private String Email;

    @Column(name = "password", nullable = false)
    private String Password;


}
